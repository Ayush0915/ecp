# 01: Jira-style board for Evolve

Mockups: `mockups/board.html`, `mockups/review.html` (screenshots in `images/`).

## The idea in one paragraph

Borrow Jira's grammar (everything is a ticket with a key, a status, links and a history), not its team features. There
are two kinds of ticket. **The ECP is a ticket**, and its board columns are the lifecycle states already enforced in
`evolve/lifecycle.py`. **Each Goldfish finding is also a ticket**, a sub-task of its ECP with its own small workflow.
The second part is the important one: today a blocker sends the plan back to the Elephant and the next round starts,
but nothing tracks whether *that* blocker was fixed, dropped, or overridden. Findings-as-tickets make the review loop
auditable.

Ticket keys: `FND-0004` (discovery finding), `ECP-0003` (evolution), `GF-0003-04` (Goldfish finding 04 on ECP-0003).

Leave out: sprints, story points, assignees, people comments, epics. Evolve is a single-user local app.

## Screen 1: ECP board

![ECP board](images/board.png)

### Columns (derived, no new state)

| Column | Source |
|---|---|
| Backlog | discovery findings with no ECP yet (needs stable finding IDs) |
| Proposed | `status == "proposed"` |
| In review | `status == "reviewed"` with open blocker/major tickets, or Goldfish still running |
| Needs you | `status == "reviewed"` with no open blockers/majors: the human approval gate |
| Executing | `status == "executing"` |
| Verifying | `status == "verified"` (waiting for decision) |
| Done | `status == "decided"`, with an outcome badge: accepted / rejected / rolled back |

### Card contents

- key, bug/feature tag, title
- **lens dot strip**: one dot per Goldfish lens. Shapes as well as colours: clean = green circle, blocker = red square,
  major = orange diamond, running = blue ring, waiting = grey circle
- round counter `R2/3` (or `step 4/6` while Pi runs)
- lock icon once the plan hash is recorded (`approved` and later)
- one badge: `1 blocker · recurred in R2`, `Waiting for your approval`, `0 writes blocked`, `Accepted`, `Rolled back`
- link line when relevant: `conflicts with ECP-0004`
- backlog cards show evidence bars (3 = reproduced, 2 = a tool agrees, 1 = model reading only) and `file:line`

### Right panel (selected card)

Key, kind, column, title, one-line summary, each lens with its state, linked tickets, last evidence-log lines, one
primary action (`Make ECP from finding`, `Approve and lock plan`, `Send blocker to Elephant`, `Watch Pi`, `Replay run`),
a link to the Goldfish board, and one line saying which rule governs this card.

### Filters

- Quick-filter chips: All, Open blockers, Needs me, Conflicts, Locked plans
- A text filter with a small JQL-like syntax: `lens:boundary sev:blocker status:open`

### Drag and drop = a transition request

- A drop calls `POST /api/ecp/<id>/transition`, which calls `lifecycle.transition()`. Only edges in `ALLOWED` succeed.
  Illegal drops snap back and show the `BadTransition` message.
- `reviewed -> approved` is human-only (that is what "Needs you" means).
- `executing -> verified` cannot be dragged; it is machine-only.
- Decided cards are read-only.

### Links

- `created from FND-xxxx` (promotion from backlog)
- `conflicts with ECP-yyyy`: computed when two non-decided ECPs both have the same file in `allowed_paths`. Conflicting
  ECPs cannot both be approved. This is a real governance check that comes free with the board.

## Screen 2: Goldfish review board (tab inside an ECP)

![Goldfish review board](images/review.png)

- Columns: **Open → Sent to Elephant → Addressed in plan → Confirmed clean → Overridden / won't fix**
- Rows (swimlanes): one per lens (Boundary, Proof, Fit, Security, Clarity, ...)
- Priority = severity from `goldfish/runner.py` (`blocker`, `major`, `nit`)
- Nits go straight to "won't fix" (they are only recorded today, matching `blocking()`)
- **Override needs a written reason**; the button is disabled until there is text. The reason goes to the evidence log.
- Counters at the top: open blockers, open majors, closed
- Right panel: severity, key, status, claim, lens, location, round raised, quote-check result, and a ticket history
  timeline

### How a ticket reaches "Confirmed clean" (keep Goldfish zero-context)

Do NOT give a fresh Goldfish the old finding and ask "is it fixed?". That breaks the zero-context rule from the
Elephant-Goldfish model. Instead:

1. Each round, every lens re-reviews the revised plan blind, exactly as today.
2. Plain code matches new findings to existing tickets by **lens + location + claim similarity**.
3. Match → the ticket reopens, tagged `recurred in R2`. No match → `Confirmed clean`.

The memory lives in the ledger, not in the reviewer.

## Backend changes

1. **Stable IDs for discovery findings** (`FND-0001`...). Today they are a list.
2. **Findings ledger per ECP**: `.evolution/findings/ECP-0003.jsonl`. One record per ticket:
   `id, lens, severity, claim, location, quote_ok, status, raised_round, resolved_round, plan_rev, override_reason,
   history[]`. Everything else on the board is derived from `.evolution/ecps/*.md` and the evidence logs.
3. **Matcher** in `goldfish/runner.py` (or a new `goldfish/ledger.py`): maps a round's findings onto existing tickets.
4. **Routes** in `dashboard/server.py`:
   - `GET  /api/board`: cards grouped by column
   - `GET  /api/ecp/<id>/findings`: tickets for the review board
   - `POST /api/ecp/<id>/transition`: wrapper over `lifecycle.transition()`
   - `POST /api/finding/<id>`: `{action: "override" | "send_back", reason}`; reason required for override
   - `POST /api/backlog/<id>/promote`: discovery finding → new ECP in Proposed

## Frontend changes

- Keep `dashboard/index.html` one vanilla file. Add hash routing: `#/board`, `#/ecp/ECP-0003`,
  `#/ecp/ECP-0003/review`.
- The current v3 run view (`docs/ui-layout-v3.jpg`) becomes the ECP detail page. Nothing is lost.

## Tests to add

- Illegal board transition is refused (each non-`ALLOWED` edge).
- Override without a reason is refused.
- A finding that recurs in the next blind round reopens its ticket.
- Two ECPs with overlapping `allowed_paths` are linked as conflicting and cannot both be approved.
