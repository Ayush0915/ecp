# Goldfish board + evolution boundary: handoff

This folder explains three planned changes to Evolve (repo `ecp`). Nothing here is built yet. These are design docs
and mockups for whoever implements them (me, or Claude/Copilot on the office laptop).

| File | What it covers |
|---|---|
| `01-board-ui.md` | Jira-style dashboard: an ECP board (lifecycle columns) and a Goldfish review board (findings as tickets) |
| `02-evolution-boundary.md` | The validation layer for the evolution boundary: floor, mutable/immutable at file and symbol level, checks before, during and after Pi |
| `03-boundary-demo.md` | A scripted demo where Pi crosses the boundary inside an allowed file and Evolve stops it |
| `mockups/board.html` | Offline clickable mockup of the ECP board (open in a browser, no internet needed) |
| `mockups/review.html` | Offline clickable mockup of the Goldfish review board inside ECP-0003 |
| `images/board.png`, `images/review.png` | Screenshots of the two mockups |

## Notes for an AI assistant reading this

- The repository is the source of truth. File and function names here were checked against the repo on 9 Nov 2026
  (`evolve/lifecycle.py`, `gate.py`, `scope.py`, `plancheck.py`, `verify.py`, `pi_runner.py`, `governance.py`,
  `goldfish/runner.py`, `dashboard/server.py`, `dashboard/index.html`). If the code has moved on, trust the code.
- Do not weaken existing guarantees: plan lock and hash (`lifecycle.assert_lock`), file scope (`scope.check_path`,
  `guard/guard-core.mjs`), the rule-only risk gate (`gate.py`: an AI can raise risk, never lower it), and the
  governance store living outside the repo (`store.py`).
- Keep the dashboard a single vanilla `index.html` with no build step. It must run on Windows + WSL.
- Mockup data (ECP ids, findings, times) is sample data, not real runs.

## Suggested order of work

1. Findings ledger (stable finding IDs + status across rounds). Both the review board and the boundary demo need it.
2. Read-only ECP board (`GET /api/board`) and the Goldfish review board.
3. Boundary layer steps 1–3 from `02-evolution-boundary.md` (floor, symbol entries, AST hash check).
4. Boundary demo scenario (`03-boundary-demo.md`), including the per-step hook and differential test.
5. Board interactions: drag = transition request, override with reason, filters and links.
