# 02: Validation layer for the evolution boundary

## What exists today (file level)

- ECP fields `allowed_paths`, `new_files`, `forbidden_paths` (`evolve/ecp.py`)
- `scope.check_path()` + `ALWAYS_PROTECTED` (`.git/**`, `.evolution/**`), mirrored in `guard/guard-core.mjs` for Pi,
  both tested against `tests/scope_cases.json`
- `plancheck.plan_problems()`: deterministic plan checks (too-broad globs, missing files, max_files, bug fix needs a test)
- `gate.assess()` / `gate.assess_diff()`: rule-only risk; an AI can raise risk, never lower it
- `verify.verify()`: changed files inside scope, tests, fail-before proof

## The gap

Pi can stay inside an allowed file and still change the behaviour of an immutable file. Example: `pricing.py` is
allowed, `payment.py` is immutable, and `payment.py` calls `pricing.round_money()`. Pi edits `round_money`. File scope
says ALLOWED, but what `payment.py` produces has changed. The validation layer exists to catch this.

## 1. Who defines the boundary

Two layers, following the same rule as `gate.py` (an AI can tighten, never loosen):

- **Floor**: repo-level immutable list in the governance store, outside the repo: new key `immutable_floor` in
  `governance.yaml` (`Governance` model, `extra="forbid"`, so it must be added to the model). The agent and the repo
  cannot edit it.
- **ECP boundary**: the Elephant declares mutable and immutable for each ECP. It can only add to the floor. Any mutable
  entry overlapping the floor makes the plan invalid before any Goldfish runs.

Proposed new ECP fields (they are part of the plan, so they are hashed and locked like the rest):

```yaml
allowed_paths: [shop/pricing.py, tests/test_pricing.py]     # existing: mutable files
forbidden_paths: [shop/payment.py]                            # existing: frozen files
mutable_symbols:   [shop/pricing.py::bulk_price]              # new: what may actually change
immutable_symbols: [shop/pricing.py::round_money]             # new: frozen even inside an allowed file
```

Plus a computed (not hashed, not written by the Elephant) field shown in the UI:

```yaml
reach_into_immutable:
  - shop/pricing.py::round_money  <-  called from shop/payment.py:12
```

### Three strengths of immutable

| Level | Meaning | Checked by |
|---|---|---|
| Frozen file | not edited at all | existing `check_path` + guard |
| Frozen symbol | this function/class body and signature unchanged | AST hash compare |
| Frozen behaviour | immutable callers get the same results | differential boundary test |

## 2. Checks before, during and after

### Before Pi (plan time)

- **Rule check** (`plancheck.plan_problems`): mutable ∩ immutable must be empty; mutable ∩ `immutable_floor` must be
  empty; every `file::symbol` must exist (parse with `ast`).
- **Reach analysis** (new `evolve/boundary.py`): build a simple call graph with Python's `ast` (imports + direct
  calls). For each mutable symbol, find callers that sit in the immutable zone. If any exist, the plan must choose:
  1. don't touch the shared function (add a new one for the mutable path), or
  2. keep it and add a **boundary proof obligation** (characterization tests that pin what the immutable caller gets), or
  3. ask the human to widen the boundary, which creates a new plan revision that is reviewed again.
  Plain-code rule: if reach is non-empty and none of these is in the plan, it is a blocking problem.
- **Boundary Goldfish lens** (rewrite `goldfish/lenses/scope_rules.md`, currently 2 lines): receives the boundary and
  the computed reach list. Covers what static analysis misses: dynamic dispatch, `getattr`, shared config or state,
  data formats, DB schema. Must quote evidence (the existing quote check applies). It can add blockers; it can never
  clear a rule failure.

### During Pi

- Keep the guard (`guard-core.mjs`) at file level: fast, simple, already tested.
- Add a per-step hook in `pi_runner.py`: after each write/edit to a `.py` file, re-hash the frozen symbols in that file.
  On mismatch: stop the run, emit `boundary_violation` to `live.jsonl`, log it in the evidence, and skip remaining Pi
  steps. (`run_scripted` is the easy place to start; the live Pi path can run the same check after each `pi_action`
  event it tails.)

### After Pi (verify)

- **Symbol check**: normalized AST hash per frozen symbol (strip docstrings/comments if you want formatting-only
  changes to pass), plus signature check for mutable functions that immutable code calls.
- **Differential boundary test** (the strongest check): in `prepare.py`, at baseline, run the immutable callers on a
  few recorded inputs and store outputs (e.g. `.evolution/boundary/<ecp>.json`). In `verify.py`, run them again. Any
  difference = violation. If the difference was intended, the boundary was declared wrong: back to the plan.
- **Second Goldfish pass**: a fresh Boundary lens reviews the real diff.
- Violation = hard failure → rollback, like the hard list in `gate.assess_diff()`.

## 3. LLM lens, rule check, or both?

Both, with different powers:

- **Rules have the final say.** A rule failure blocks, and no LLM output can overturn it.
- **The Goldfish lens can only add blockers**, each backed by a verified quote.
- **A human may override an ECP-level immutable** with a written reason (evidence log). **The floor cannot be
  overridden** from inside a run.

In the review board, boundary tickets are labelled `rule` or `lens`. Rule tickets on the floor have no override button.

## 4. Honest limits (say these to the mentor)

- A static call graph in Python misses `getattr`, monkeypatching and injected dependencies.
- Differential tests only cover the inputs you sampled.

So the layer does not prove the boundary held. It makes every crossing either blocked, proven by evidence, or
overridden with a recorded reason. That is a defensible meaning of "controlled".

## 5. Build order

1. `immutable_floor` in `Governance` + consistency checks in `plancheck.py`
2. `evolve/boundary.py`: parse `file::symbol`, AST hash per symbol, reach lookup
3. Symbol + signature checks in `verify.py`; per-step hook in `pi_runner.py`
4. Differential boundary test: record in `prepare.py`, re-run in `verify.py`
5. Boundary Goldfish lens (replace `scope_rules.md`)
6. Scenario fixture `6_boundary_crossed_via_shared_helper.json` (see `03-boundary-demo.md`)
7. Tests: overlap with floor rejected; reach without an option chosen rejected; frozen symbol edit stops Pi; behaviour
   change caught by differential test while normal tests pass
